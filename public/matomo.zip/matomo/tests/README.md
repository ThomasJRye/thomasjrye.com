Matomo comes with unit tests, integration tests, system tests, Javascript tests and UI tests.

To learn more about Matomo tests check out these sections on our developer website:

* [Matomo Tests](https://developer.matomo.org/guides/tests)
* [Matomo Tests - In Depth](https://developer.matomo.org/guides/tests-system)
